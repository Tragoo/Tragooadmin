import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../constants/TitleText.dart';
import '../services/sendnotifications.dart';


class SendNotification extends StatefulWidget {
  const SendNotification({Key? key}) : super(key: key);

  @override
  State<SendNotification> createState() => _SendNotificationState();
}

class _SendNotificationState extends State<SendNotification> {
  TextEditingController NotificationMessage = TextEditingController();
  String message = "";
  final formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(13)),
                      color:
                      Colors.transparent ,

                    ),
                    height: 50,
                    width: 50,

                    child: Center(
                        child: Icon(
                          Icons.arrow_back,
                          color: Colors.black,
                          size: 30,
                        )),


                  ),
                ),
              ),
              _title(),
              SizedBox(height: 10,),
              _submitForm()
            ],
          ),
        ),
      ),
    );
  }
  Widget _submitForm() {
    return Form(
        key: formKey,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              TextFormField(
                keyboardType: TextInputType.name,
                controller: NotificationMessage,
                maxLines: 3,
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    filled: true,
                    fillColor: Color(0xFFEDECF2),
                    hintText: "Type Message",

                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "please type message";
                  }
                },
                onSaved: (value) {
                  message = value!;
                },
              ),
              SizedBox(height: 10,),
              TextButton(
                onPressed: () {
                  final isvalid = formKey.currentState!.validate();
                  if (isvalid) {
                    formKey.currentState!.save();

                    FirebaseFirestore.instance.collection("Notifications").doc(DateTime.now().toString()).set(
                        {
                          "dateTime":DateTime.now().toString(),
                          "Message": message
                        }
                    ).then((value) {
                      sendNotificationstoAllAdmins(message);

                    });
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Notification sent to all users")));
                    formKey.currentState!.reset();

                  }

                },
                style: ButtonStyle(
                  shape: MaterialStateProperty.all(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                  ),
                  backgroundColor:
                  MaterialStateProperty.all<Color>(Colors.blue),
                ),
                child: Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.symmetric(vertical: 4),
                  width: MediaQuery
                      .of(context)
                      .size
                      .width * .8,
                  child: TitleText(
                    text: "Send Notification",
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),

            ],
          ),
        ));
  }
  Widget _title() {
    return Container(
        margin:  const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                TitleText(
                  text:  'Send',
                  fontSize: 27,
                  fontWeight: FontWeight.w400,
                ),
                TitleText(
                  text:  'Notifications',
                  fontSize: 27,
                  fontWeight: FontWeight.w700,
                ),
              ],

            ),

          ],
        ));
  }
  void sendNotificationstoAllAdmins(String message) async {
    SendPushNotification notificationclass = SendPushNotification();
    String title = 'New Message';
    String body = message;
    QuerySnapshot usersSnapshot =
    await FirebaseFirestore.instance.collection('user_details').get();
    List usertokenlist = usersSnapshot.docs.toList();
    for (var element in usertokenlist) {
      String token = element["token"].toString();
      notificationclass.sendOrderPushNotificationsToAdmins(
          body, title, token, "12345", "250");
    }
  }
}
