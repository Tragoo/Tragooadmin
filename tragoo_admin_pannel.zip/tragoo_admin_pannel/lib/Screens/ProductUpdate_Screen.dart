import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../constants/TitleText.dart';

class ProductDetail extends StatefulWidget {
  final List ProductDetailsList;
  final int index;
  const ProductDetail({Key? key, required this.ProductDetailsList, required this.index}) : super(key: key);

  @override
  State<ProductDetail> createState() => _ProductDetailState();
}

class _ProductDetailState extends State<ProductDetail> {
  TextEditingController quantityCont = TextEditingController();
  TextEditingController priceCont = TextEditingController();
  final SnackBar _snackBar = SnackBar(content: Text("Product Updated Succesfully"));
  void UpdateProduct(String quantity,String price) async {
    final QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('products_details')
        .where('productId',
        isEqualTo:
        widget.ProductDetailsList[widget.index]['productId'].toString())
        .get();

    final DocumentSnapshot userDoc = querySnapshot.docs.first;
    final DocumentReference userRef = userDoc.reference;

    await userRef.update({
      'Quantity': quantity,
       'Price':double.parse(price)
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                    decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(13)),
                      color: Colors.transparent,
                    ),
                    height: 50,
                    width: 50,
                    child: const Center(
                        child: Icon(
                          Icons.arrow_back,
                          color: Colors.black,
                          size: 30,
                        )),
                  ),
                ),
              ),
              _title(),
              Image.network(widget.ProductDetailsList[widget.index]['ImageList'][0],height: 400,width: MediaQuery.of(context).size.width,),

             Row(
                children: [
                  TitleText(text: " Quantity",fontSize:18 ,fontWeight: FontWeight.normal,),
                  SizedBox(width: 10,),
                  Container(
                    height:40,
                    width: 160,
                    child: TextFormField(
                      controller: quantityCont,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(


                        ),
                        filled: true,
                        fillColor: Color(0xFFEDECF2),
                        hintText: widget.ProductDetailsList[widget.index]['Quantity'],
                      ),
                      validator: (value){
                        if(value == null)
                          {
                            return "Error";
                          }
                      },
                    ),
                  )
                ],
              ),
              SizedBox(height: 10,),
              Row(
                children: [
                  TitleText(text: " Price      ",fontSize:18 ,fontWeight: FontWeight.normal,),
                  SizedBox(width: 10,),
                  Container(
                    height:40,
                    width: 160,
                    child: TextFormField(
                      controller: priceCont,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(


                        ),
                        filled: true,
                        fillColor: Color(0xFFEDECF2),
                        hintText: widget.ProductDetailsList[widget.index]['Price'].toString(),
                      ),
                      validator: (value){
                        if(value == null)
                        {
                          return "Error";
                        }
                      },
                    ),
                  )
                ],
              ),
              SizedBox(height: 30,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                child: TextButton(
                  onPressed: () async{
                    UpdateProduct(quantityCont.text,priceCont.text);
                    ScaffoldMessenger.of(context).showSnackBar(_snackBar);
                  },
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                  ),
                  child: Container(
                    alignment: Alignment.center,
                    padding: EdgeInsets.symmetric(vertical: 4),
                    width: MediaQuery.of(context).size.width * .75,
                    child: TitleText(
                      text: "Update",
                      color: Color(0XFFFFFFFF),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
  Widget _title() {
    return Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                    padding: EdgeInsets.symmetric(vertical: 8,horizontal: 20),
                    child:TitleText(text: widget.ProductDetailsList[widget.index]['Title'],fontSize: 22,color: Colors.black,fontWeight: FontWeight.bold,)

                ),
              ],
            ),
          ],
        ));
  }
}
