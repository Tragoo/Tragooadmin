import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'Screens/splash.dart';
import 'package:just_audio/just_audio.dart';
import 'Utilities/constants/internationalization.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      translations: LocaleStrings(),
      debugShowCheckedModeBanner: false,
      locale: const Locale('en', 'US'),
      home: SplashScreen(),
    );
  }
}

AudioPlayer player = AudioPlayer();
