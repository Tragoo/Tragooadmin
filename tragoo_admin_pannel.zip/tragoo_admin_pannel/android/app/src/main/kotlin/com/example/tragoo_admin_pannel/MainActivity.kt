package com.app.tragoo_admin_pannel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
